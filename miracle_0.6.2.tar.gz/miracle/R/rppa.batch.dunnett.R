rppa.batch.dunnett <-
function(batch.result, referenceSample, p.cutoff=1, sample.subset=NA, duplicate.nas=T)
{
  #subset sample
  if(!is.na(sample.subset)[1]){
    batch.result <- lapply(batch.result, function(x, sample.subset, duplicate.nas){
      result <- subset(x, Sample %in% sample.subset)
      result <- rppa.duplicate.nas(result)
      result$Sample <- factor(result$Sample, sample.subset)
      return(result)
    }, sample.subset=sample.subset, duplicate.nas=duplicate.nas)
  }
  
  #for each of the slides calculate the test statistics (pairwise comparison using t-test with multiple comparison adjustment)
  pvalues <- foreach(slide=batch.result, .combine=rbind) %dopar%
  {
    rppa.dunnett(slide, referenceSample)
  }
  pvalues$Samples <- factor(pvalues$Samples, paste(sample.subset, "-", referenceSample))
  
  rppa.batch.dunnett.plot(pvalues, p.cutoff)
  
  return(pvalues)
}
