foo <-
function(x, A, B, alpha=0, beta=10/(B-A)) {
  A + (B-A)*ea(alpha+beta*x)
}
