update_x_infinity <-
function(xi,yi,fit,coefficient,prediction,lowerbound,balance,nrep,x.old,i,fity,data,numsearchpt,windowsize,x.hat){
  
  weights<-abs(deriv_for_spline(xi,fit,coefficient));
  value<-inverse_for_spline(yi,fit,coefficient,prediction,lowerbound);
  value<-value-rep(balance,nrep);
  
  if(max(round(weights,4))!=0){
    rqfit<-rq(value~1,weights=weights)
    c1<-rqfit$coefficients[1]
    x.update=c(rep(c1,nrep))
  } else  {   x.update=rep(median(xi),nrep) }
  
  if( max(abs(x.update-x.old[(nrep*(i-1)+1:nrep)]))>2 )
  {
    temp=getnewxrep(nrep,fity,x.old[nrep*(i-1)+1],data[(nrep*(i-1)+1):(nrep*i),],numsearchpt,windowsize,miny=500,disminyy=2000,lowxwt=1,data,x.hat,balance)
    x.update=rep(temp$output,nrep)
  }
  return(x.update)
}
