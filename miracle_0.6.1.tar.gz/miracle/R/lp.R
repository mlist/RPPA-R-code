lp <-
function(p) {
  p=ifelse(p<0.0000001,0.0000001,p)
  logb(p/(1-p), 2)}
