getfityrep <-
function(x,x0mat,fity,nrep,data){
  fityrep=fity[seq(1,length(fity),by=nrep)]
  x0matsub=x0mat[seq(1,dim(data)[1],by=nrep),]
  x0vec=as.vector(x0matsub)
  
  if (x<min(x0vec)) youtput=fityrep[x0vec==min(x0vec)]
  if (x>max(x0vec)) youtput=fityrep[x0vec==max(x0vec)]
  
  if (sum(x0vec==x)>0) {
    youtput=fityrep[x0vec==x]
    if (length(youtput)>1) youtput=youtput[1]     }
  if (sum(x0vec==x)==0 && x>min(x0vec) && x<max(x0vec)){
    
    x0vecsub=x0vec[(x0vec-x)>0]
    fitysub=fityrep[(x0vec-x)>0]
    xright=x0vecsub[(x0vecsub-x)==min(x0vecsub-x)]
    yright=fitysub[(x0vecsub-x)==min(x0vecsub-x)]
    
    if (length(xright)>1) {xright=xright[1]; yright=yright[1]}
    x0vecsub=x0vec[(x0vec-x)<0]
    fitysub=fityrep[(x0vec-x)<0]
    xleft=x0vecsub[(x0vecsub-x)==max(x0vecsub-x)]
    yleft=fitysub[(x0vecsub-x)==max(x0vecsub-x)]
    
    if (length(xleft)>1) {xleft=xleft[1]; yleft=yleft[1]}
    
    if (length(xright)>0 && length(xleft)>0){
      lineslope=(yright-yleft)/(xright-xleft)
      lineint=yleft-lineslope*xleft
      youtput=lineint+lineslope*x
    }
  }
  
  if (length(youtput)>1) youtput=youtput[1]
  return(youtput)
}
