rppa.serialDilution.format <-
function(spots, inducerOnlyName=T) {  
  require(reshape)
  
  title <- attr(spots, "title")
  
  #filter NA values
  spots <- spots[!is.na(spots$DilutionFactor),]
  
  #transform continuous into descrete
  spots$DilutionFactor <- as.factor(spots$DilutionFactor)
  
  #extract inducer name
  #if(inducerOnlyName==T) spots$Inducer <- gsub(" [0-9]+[.][0-9] mM", "", spots$Inducer )
  
  #cast into table
  spots.c <- cast(spots, CellLine + NumberOfCellsSeeded + SampleName + SampleType + TargetGene + SpotType + SpotClass + Deposition + Treatment + LysisBuffer + Inducer ~ DilutionFactor, value="Signal", add.missing=TRUE, fun.aggregate="median", na.rm=T)
  
  return(spots.c)
}
