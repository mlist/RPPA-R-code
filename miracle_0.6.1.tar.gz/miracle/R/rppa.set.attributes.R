rppa.set.attributes <-
function(spots)
{
  cat("Title of the Slide / Experiment?")
  title <- readline()
  
  cat("Antibody?")
  antibody <- readline()
  
  cat("Blocks per row?")
  blocksPerRow <- readline()
  
  attr(spots, "title") <- title
  attr(spots, "blocksPerRow") <- as.numeric(blocksPerRow)
  attr(spots, "antibody") <- antibody
  
  #cat("Do you want to apply vertical and horizontal shifts? yes/no")
  #if(readline() == "yes")
  #{
  #  spots <- rppa.vshift(spots)
  #  spots <- rppa.hshift(spots)
  #}
  return(spots)
}
