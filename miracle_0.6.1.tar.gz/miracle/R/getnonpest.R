getnonpest <-
function(data,nrep,randW=FALSE){
  
  #####the first step#####
  
  ###obtain the initial value x###
  
  nsamp = nrow(data)
  ndilut = ncol(data)
  balance = (1:ndilut)-(1+ndilut)/2
  
  # make a first guess at the extreme levels we might see
  mini = apply(data, 1, min)
  maxi = apply(data, 1, max)
  A = min(mini)
  B = max(maxi)
  
  # transform the data to where it should be linear
  
  lindata = lp((data-A)/(B-A))
  
  # initial estimate of the logistic slope across the dilution steps
  
  beta = mean(apply(lindata, 1, function(x){
    y = x[!is.na(x) & !is.infinite(x)]
    max(y)-min(y)
  }))/(ndilut-1)
  
  
  # for each sample, estimate the offset
  
  passer = apply(lindata, 1, function(x, beta, balance) {
    median(x/beta - balance)
  }, beta, balance)
  
  passermat=matrix(passer,ncol=nrep,byrow=T)
  passeravg=apply(passermat,1,mean)
  passeravg=passeravg-median(passeravg)
  passeravg=rep(passeravg,each=nrep)
  
  ###the second step###
  ###doing 5 iterations###
  x0new=passeravg
  
  if(randW){weights=rexp(length(as.vector(data)))}else
  {weights=rep(1,length(as.vector(data)))}
  for (ii in 1:5){
    
    numsearchpt=ii*20
    x0mat=NULL
    for (i in 1:nrow(data)) x0mat=rbind(x0mat,balance+x0new[i])
    
    if (ii==1) {a=cobs(as.vector(x0mat),as.vector(data),w=weights, nknots=40,constraint="increase",lambda=-1,print.warn = FALSE, print.mesg = FALSE)
                lambda1=a$lambda}
    if (ii >1)   a=cobs(as.vector(x0mat),as.vector(data),w=weights, nknots=40,constraint="increase",lambda=lambda1,print.warn = FALSE, print.mesg = FALSE)
    fity=fitted(a)
    
    aknot=a$knots
    acoef=a$coef
    
    if (ii<5) windowsize=2
    if (ii==5) windowsize=1
    
    x0old=x0new
    x0new=NULL
    
    for (i in 1:(dim(data)[1]/nrep)){
      Y = as.vector(data[(nrep*(i-1)+1):(nrep*i),])
      Steps = rep(balance,each=nrep)
      
      nlrqres=nlrq(Y ~ fspline(X+Steps,aknot,acoef),start = list(X = x0old[(nrep*(i-1)+1)]), trace = FALSE, control=nlrq.control(maxiter=20,eps=1e-03))
      
      tmp = try(nlrqres, TRUE)
      if (length(coef(tmp))==0) x0new=c(x0new, x0old[(nrep*(i-1)+1)])
      if (length(coef(tmp))>0 && abs(coef(tmp)-x0old[(nrep*(i-1)+1)])>2){
        temp=getnewxrep(nrep,fity,x0old[nrep*(i-1)+1],data[(nrep*(i-1)+1):(nrep*i),],numsearchpt,windowsize,miny=500,disminyy=2000,lowxwt=1,data,x0mat,balance)
        x0new=c(x0new,temp$output)
      }
      if (length(coef(tmp))>0 && abs(coef(tmp)-x0old[(nrep*(i-1)+1)])<=2) x0new = c(x0new, coef(tmp))
    }
    x0new=x0new-median(x0new)
    x0new1=x0new
    x0new=rep(x0new,each=nrep)
    
  }
  x0mat=NULL
  for (i in 1:nrow(data)) x0mat=rbind(x0mat,balance+x0new[i])
  a=cobs(as.vector(x0mat),as.vector(data),nknots=40,constraint="increase",lambda=lambda1,print.warn = FALSE, print.mesg = FALSE)
  return(list(x0new=x0new1,lambda1=lambda1,fitted=matrix(fity,nsamp,ndilut),residuals=matrix(data-fity,nsamp,ndilut),fit=a))
}
