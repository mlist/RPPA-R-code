dilutionFitrep <-
function(data, nrep, verbose=FALSE, trace=FALSE) {
  
  # We assume the data is in the form of a matrix, with each row
  # representing a dilution series (increasing concentrations)
  # for the same protein in a different sample. Try to fit a
  # common logistic curve, placing all series appropriately
  # along it.
  
  nsamp = nrow(data)
  ndilut = ncol(data)
  balance = (1:ndilut)-(1+ndilut)/2
  
  # make a first guess at the extreme levels we might see
  mini = apply(data, 1, min)
  maxi = apply(data, 1, max)
  A = min(mini)
  B = max(maxi)
  
  # transform the data to where it should be linear
  lindata = lp((data-A)/(B-A))
  
  # initial estimate of the logistic slope across the dilution steps
  beta = mean(apply(lindata, 1, function(x){
    y = x[!is.na(x) & !is.infinite(x)]
    max(y)-min(y)
  }))/(ndilut-1)
  
  # for each sample, estimate the offset
  passer = apply(lindata, 1, function(x, beta, balance) {
    median(x/beta - balance)
  }, beta, balance)
  
  
  passermat=matrix(passer,ncol=nrep,byrow=T)
  passeravg=apply(passermat,1,mean)
  passer=rep(passeravg,each=nrep)
  
  
  # put our current guess at the x and y values into vectors
  
  xval = rep(balance, nsamp) + rep(passer, each=ndilut)
  yval = as.vector(t(data))
  ox = order(xval)
  A2 = median(yval[ox][1:100])
  B2 = median(rev(yval[ox])[1:100])
  
  dum = data.frame(xval=xval, yval=yval)
  nls.model = nls(yval ~ alpha + beta*ea(gamma*xval), data=dum,
                  start=list(alpha=A, beta=B-A, gamma=beta),
                  control=nls.control(maxiter=10000,minFactor=1/2^50))
  
  cf = coef(nls.model)
  p.alpha = cf['alpha']
  p.beta  = cf['beta']
  p.gamma = cf['gamma']
  
  pass2 = rep(NA, (nrow(data)/nrep))
  warn2  = rep('', (nrow(data)/nrep))
  names(warn2) = (dimnames(data)[[1]])[seq(1,nrow(data),by=nrep)]
  
  for (i in 1:(nrow(data)/nrep)) {
    if(verbose) print(i)
    dum = data.frame(Y=as.vector(data[(nrep*(i-1)+1):(nrep*i),]),B=rep(balance,each=nrep))
    dum$p.alpha = p.alpha
    dum$p.beta = p.beta
    dum$p.gamma = p.gamma
    
    tmp = try(nls(Y ~ p.alpha + p.beta*ea(p.gamma*(B+X)), data=dum,
                  start=list(X=passer[nrep*(i-1)+1]),trace=trace,control=nls.control(maxiter=10000,minFactor=1/2^50)))
    
    if (is(tmp, 'try-error')) {
      warning('nls error')
      warn2[i] = paste(warn2[i], 'nls-error', collapse=' ')
      tmp = try(nls(Y ~ p.alpha + p.beta*ea(p.gamma*(B+X)), data=dum,
                    start=list(X=passer[nrep*(i-1)+1]),trace=trace, algorithm='plinear',
                    control=nls.control(maxiter=10000,minFactor=1/2^50)))
      
      if (is(tmp, 'try-error')) {
        warning('unavoidable nls error')
        warn2[i] = paste(warn2[i], 'unavoidable nls-error')
        pass2[i] = passer[nrep*(i-1)+1]
      } else {
        pass2[i] = coef(tmp)['X']
      }
    } else {
      pass2[i] = coef(tmp)
    }
  }
  
  list(A=A, B=B, A2=A2, B2=B2, passer=passer, pass2=pass2,
       p.alpha=p.alpha, p.beta=p.beta, p.gamma=p.gamma, balance=balance,
       warn=warn2, fit=nls.model)
}
