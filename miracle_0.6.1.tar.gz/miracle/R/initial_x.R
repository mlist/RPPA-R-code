initial_x <-
function(data,nrep=1){
  
  ####### First Guess #######
  ####### Treat them individually #######
  
  nsamp = nrow(data)
  ndilut = ncol(data)
  ntotal = nsamp*ndilut
  balance = (1:ndilut)-(1+ndilut)/2
  
  mini = apply(data, 1, min)
  maxi = apply(data, 1, max)
  A = min(mini)
  B = max(maxi)
  
  lindata = lp((data-A)/(B-A))
  
  beta = mean(apply(lindata, 1, function(x){
    y = x[!is.na(x) & !is.infinite(x)]
    max(y)-min(y)
  }))/(ndilut-1)
  
  passer = apply(lindata, 1, function(x, beta, balance) {
    median(x/beta - balance)
  }, beta, balance)
  
  passermat=matrix(passer,ncol=nrep,byrow=T)
  passeravg=apply(passermat,1,mean)
  passeravg=passeravg-median(passeravg)
  
  x.new=rep(passeravg,each=nrep)
  x.hat<-matrix(rep(passeravg,each=ndilut*nrep)+rep(balance,nsamp),nrow=nsamp,ncol=ndilut,byrow=T)
  initial<-x.new
  initial=matrix(initial,nrep,(nsamp/nrep))
  
  list(initial=initial,x.hat=x.hat,x.new=x.new)
}
