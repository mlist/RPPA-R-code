rppa.calculate.cv <-
function(x) { y <- sd(x) / mean(x); return(y)}
