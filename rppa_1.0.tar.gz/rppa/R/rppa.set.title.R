rppa.set.title <-
function(spots, title)
{
  attr(spots, "title") <- title
  
  return (spots)
}
