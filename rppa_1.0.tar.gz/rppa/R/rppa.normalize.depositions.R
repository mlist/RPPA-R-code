rppa.normalize.depositions <-
function(spots)
{
  spots <- within(spots, {
    Signal <- Signal / as.numeric(Deposition)
    FG <- FG / as.numeric(Deposition)
    BG <- BG / as.numeric(Deposition)
  })
  
  return(spots)
}
