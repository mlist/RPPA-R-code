update_x_lam2 <-
function(xi,yi,fit,XX,coefficient,prediction,lowerbound,balance,nrep,lambda2,x.old,i,fity,data,numsearchpt,windowsize,x.hat,ndilut){
  
  weights<-abs(deriv_for_spline(xi,fit,coefficient));
  value<-inverse_for_spline(yi,fit,coefficient,prediction,lowerbound);
  value<-value-rep(balance,nrep);
  
  if(max(round(weights,4))!=0){
    yy<-c(value,0,0,0)
    weights<-c(weights,lambda2,lambda2,lambda2)
    rqfit<-rq(yy~XX-1,weights=weights)
    x.update=c(rqfit$coefficients[1],rqfit$coefficients[2],rqfit$coefficients[3])
  } else  {   x.update=rep(median(xi),nrep)}
  
  if( max(abs(x.update-x.old[(nrep*(i-1)+1:nrep)]))>2 )
  {
    temp1=getnewxrep(nrep,fity,x.old[nrep*(i-1)+1],data[(nrep*(i-1)+1):(nrep*i),],numsearchpt,windowsize,miny=500,disminyy=2000,lowxwt=1,data,x.hat,balance)
    x_nrep3=rep(temp1$output,nrep)
    x_nrep1=NULL;
    
    for(ww in 1:nrep)
    {
      temp2=getnewxrep(nrep=1,fity,x.old[nrep*(i-1)+ww],data[nrep*(i-1)+ww,],numsearchpt,windowsize,miny=500,disminyy=2000,lowxwt=1,data,x.hat,balance)
      x_nrep1=c(x_nrep1,temp2$output)
    }
    
    loss_nrep3=sum(weights[1:(ndilut*nrep)]*abs((rep(x_nrep3,each=ndilut)-value)))
    loss_nrep1=sum(weights[1:(ndilut*nrep)]*abs((rep(x_nrep1,each=ndilut)-value)))+lambda2*(abs(x_nrep1[1]-x_nrep1[2])+abs(x_nrep1[1]-x_nrep1[3])+abs(x_nrep1[3]-x_nrep1[2]))
    
    if(loss_nrep3<loss_nrep1) x.update=x_nrep3 else {x.update=x_nrep1}
  }
  return(x.update)
}
