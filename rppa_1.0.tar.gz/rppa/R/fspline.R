fspline <-
function(xvec, aknot, acoef){
  
  nknot=length(aknot)
  aknotnew=c(aknot[1], aknot[1],aknot, aknot[nknot], aknot[nknot])
  ncoef=length(acoef)
  
  xvec[xvec<(aknot[1]+(1e-8))]=aknot[1]+(1e-8)
  xvec[xvec > (aknot[nknot]-(1e-8))]=aknot[nknot]-(1e-8)
  
  if (ncoef == nknot + 2)
  {acoefnew=acoef[-ncoef]
   a=spline.des(aknotnew, xvec,ord=3)
   fvalvec= (a$design)%*%acoefnew
  }
  
  return(fvalvec)
}
