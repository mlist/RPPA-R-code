rppa.superCurve.create.sample.names <-
function(spots, select.columns.sample, select.columns.A, select.columns.B, select.columns.fill){
  if(length(select.columns.sample) > 1 )
    Sample <- as.data.frame(apply(spots[,select.columns.sample], 1, paste, collapse=" | "))
  else Sample <- as.data.frame(spots[,select.columns.sample])
  
  if(!is.null(select.columns.A) && !is.na(select.columns.A))
  {
    if(length(select.columns.A) > 1)
      Sample <- cbind(Sample, apply(spots[,select.columns.A], 1, paste, collapse=" | "))
    else Sample <- cbind(Sample, spots[,select.columns.A])
  }  
  
  if(!is.null(select.columns.B) && !is.na(select.columns.B))
  {
    if(length(select.columns.B) > 1)
      Sample <- cbind(Sample, apply(spots[,select.columns.B], 1, paste, collapse=" | "))
    else Sample <- cbind(Sample, spots[,select.columns.B])
  }
  
  if(!is.null(select.columns.fill) && !is.na(select.columns.fill))
  {
    if(length(select.columns.fill) > 1)
      Sample <- cbind(Sample, apply(spots[,select.columns.fill], 1, paste, collapse=" | "))
    else Sample <- cbind(Sample, spots[,select.columns.fill])
  }
  
  return(Sample)
}
