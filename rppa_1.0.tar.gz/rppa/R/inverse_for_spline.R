inverse_for_spline <-
function(yy,fit,coefficient,prediction,lowerbound){
  
  e=10^(-3)
  yy=round(yy,3)
  
  yy[yy<=prediction[1,2]]=prediction[1,2]+e
  yy[yy>=(prediction[dim(prediction)[1],2])]=(prediction[dim(prediction)[1],2])-e
  yy=t(t(yy))
  
  yy.tf=t(apply(yy, 1, function(x,knot){x>prediction[,2]}, prediction));
  yy.interval=apply(yy.tf,1,sum);
  
  yy[yy==prediction[yy.interval,2]]=yy[yy==prediction[yy.interval,2]]+e;
  
  yy.interval=yy.interval+lowerbound-1;
  
  a=coefficient[yy.interval,1]
  b=coefficient[yy.interval,2]
  c=coefficient[yy.interval,3]
  
  # Here, we have to take the sign into consideration.
  # If a>0, we need to pick up the larger one to make the whole curve incresing
  # If a<0, we need to pick up the samller one to make the curve increasing
  # In general, we have to pick up the one with -b+sqrt(~)
  inve<-(-b+sqrt(apply(b^2-4*a*c+4*a*yy,1, function(x) {max(0,x)})))/2/a
  return(as.vector(inve))
}
