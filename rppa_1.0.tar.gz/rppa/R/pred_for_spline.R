pred_for_spline <-
function(fit){
  
  knot=fit$knots
  rank=1:length(knot)
  
  e=10^(-3)
  
  prediction=predict(fit,knot[1:length(knot)-1])
  prediction=rbind(prediction,predict(fit,knot[length(knot)]-e))
  prediction[,2]=round(prediction[,2],3)
  
  # removing the flat region.
  # lowerbound will denote the start interval, after removing the flat region.
  
  lowerbound=max(rank[prediction[,2]==min(prediction[,2])])
  upperbound=min(rank[prediction[,2]==max(prediction[,2])])
  
  prediction=prediction[lowerbound:upperbound,]
  
  list(prediction=prediction,lowerbound=lowerbound)
}
