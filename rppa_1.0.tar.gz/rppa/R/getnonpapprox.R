getnonpapprox <-
function(data,nrep=3,lambda2="infinity",CVindex="NULL",step.max=8){
  
  nsamp = nrow(data);
  ndilut = ncol(data);
  ntotal = nsamp*ndilut;
  balance = (1:ndilut)-(1+ndilut)/2;
  step = 1;
  
  x.ini = initial_x(data,nrep=3)
  x.hat = x.ini$x.hat
  x.new = x.ini$x.new
  
  Track.x=matrix(NA,nsamp,4) # we track the last 4 steps.
  
  #### lam2=Inifity
  if(lambda2=="infinity") {
    while(step<=step.max)
    {
      numsearchpt=step*20
      
      if (step<step.max) windowsize=2
      if (step==step.max) windowsize=1
      
      if(step==1) {fit=cobs(as.vector(x.hat),as.vector(data),nknots=40,constraint='increase',lambda=-1,print.warn = FALSE, print.mesg = FALSE);lambda=fit$lambda;}
      if(step!=1) {fit=cobs(as.vector(x.hat),as.vector(data),nknots=40,constraint='increase',lambda=lambda,print.warn = FALSE, print.mesg = FALSE);}
      fity=fitted(fit);
      
      x.old=x.new;
      x.new<-NULL;
      
      coefficient=coef_for_spline(fit);
      junk.pred=pred_for_spline(fit);
      prediction=junk.pred$prediction;
      lowerbound=junk.pred$lowerbound;
      
      for(i in 1:(nsamp/nrep))
      {
        xi<-as.vector(t(x.hat[nrep*(i-1)+1:nrep,]));   # x_j+d_l are read
        yi<-as.vector(t(data[nrep*(i-1)+1:nrep,]));
        x.new<-c(x.new,update_x_infinity(xi,yi,fit,coefficient,prediction,lowerbound,balance,nrep,x.old,i,fity,data,numsearchpt,windowsize,x.hat))
      }
      
      x.new=x.new-median(x.new)
      x.hat<-matrix(rep(x.new,each=ndilut)+rep(balance,nsamp),nrow=nsamp,ncol=ndilut,byrow=T)
      if(step>=step.max-3) Track.x[,(4+step-step.max)]=x.new
      step=step+1
    }
    
    fit=cobs(as.vector(x.hat),as.vector(data),nknots=40,constraint='increase',lambda=lambda,print.warn = FALSE, print.mesg = FALSE)
    
    x.final<-NULL;
    for(jj in 1:(nsamp/nrep)){
      track.xi=Track.x[nrep*(jj-1)+1:nrep,]
      yi=data[nrep*(jj-1)+1:nrep,]
      x.final<-c(x.final,final_x(track.xi,yi,fit,ndilut,nrep,balance))
    }
    x.final<-x.final-median(x.final)
    x.hat.final<-matrix(rep(x.final,each=ndilut)+rep(balance,nsamp),nrow=nsamp,ncol=ndilut,byrow=T)
    fit=cobs(as.vector(x.hat.final),as.vector(data),nknots=40,constraint='increase',lambda=lambda,print.warn = FALSE, print.mesg = FALSE)
    
  } else
    
    #### lam2: Finite
  {
    # Define the design matrix "XX" first
    x1<-c(rep(1,ndilut),rep(0,2*ndilut));
    x2<-c(rep(0,ndilut),rep(1,ndilut),rep(0,ndilut));
    x3<-c(rep(0,2*ndilut),rep(1,ndilut));
    X<-cbind(x1,x2,x3);
    XX=rbind(X,c(1,-1,0),c(0,1,-1),c(1,0,-1));
    
    if(CVindex=="NULL"){
      while(step<=step.max)
      {
        numsearchpt=step*20
        
        if (step<step.max) windowsize=2
        if (step==step.max) windowsize=1
        
        if(step==1) {fit=cobs(as.vector(x.hat),as.vector(data),nknots=40,constraint='increase',lambda=-1,print.warn = FALSE, print.mesg = FALSE);lambda=fit$lambda;}
        if(step!=1) {fit=cobs(as.vector(x.hat),as.vector(data),nknots=40,constraint='increase',lambda=lambda,print.warn = FALSE, print.mesg = FALSE);}
        fity=fitted(fit);
        
        x.old=x.new;
        x.new<-NULL;
        
        coefficient=coef_for_spline(fit);
        junk.pred=pred_for_spline(fit);
        prediction=junk.pred$prediction;
        lowerbound=junk.pred$lowerbound;
        
        for(i in 1:(nsamp/nrep))
        {
          xi<-as.vector(t(x.hat[nrep*(i-1)+1:nrep,]));   # x_j+d_l are read
          yi<-as.vector(t(data[nrep*(i-1)+1:nrep,]));
          x.new<-c(x.new,update_x_lam2(xi,yi,fit,XX,coefficient,prediction,lowerbound,balance,nrep,lambda2,x.old,i,fity,data,numsearchpt,windowsize,x.hat,ndilut))
        }
        
        x.new=x.new-median(x.new)
        x.hat<-matrix(rep(x.new,each=ndilut)+rep(balance,nsamp),nrow=nsamp,ncol=ndilut,byrow=T)
        if(step>=step.max-3) Track.x[,(4+step-step.max)]=x.new
        step=step+1
        
      }
      
      fit=cobs(as.vector(x.hat),as.vector(data),nknots=40,constraint='increase',lambda=lambda,print.warn = FALSE, print.mesg = FALSE)
      x.final<-NULL;
      for(jj in 1:(nsamp/nrep)){
        track.xi=Track.x[nrep*(jj-1)+1:nrep,]
        yi=data[nrep*(jj-1)+1:nrep,]
        x.final<-c(x.final,final_x(track.xi,yi,fit,ndilut,nrep,balance))
      }
      x.final<-x.final-median(x.final)
      x.hat.final<-matrix(rep(x.final,each=ndilut)+rep(balance,nsamp),nrow=nsamp,ncol=ndilut,byrow=T)
      fit=cobs(as.vector(x.hat.final),as.vector(data),nknots=40,constraint='increase',lambda=lambda,print.warn = FALSE, print.mesg = FALSE)
      
    } else
    {
      #### lam2: Cross validation
      
      ndilut=ndilut-1;
      data_rec<-data
      x.hat_rec<-x.hat
      balance_rec<-balance
      data=data[,-CVindex]
      x.hat=x.hat[,-CVindex]
      balance=balance[-CVindex]
      
      x1<-c(rep(1,ndilut),rep(0,2*ndilut));
      x2<-c(rep(0,ndilut),rep(1,ndilut),rep(0,ndilut));
      x3<-c(rep(0,2*ndilut),rep(1,ndilut));
      X<-cbind(x1,x2,x3);
      XX=rbind(X,c(1,-1,0),c(0,1,-1),c(1,0,-1));
      
      while(step<=step.max)
      {
        numsearchpt=step*20
        
        if (step<step.max) windowsize=2
        if (step==step.max) windowsize=1
        
        if(step==1) {fit=cobs(as.vector(x.hat),as.vector(data),nknots=40,constraint='increase',lambda=-1,print.warn = FALSE, print.mesg = FALSE);lambda=fit$lambda;}
        if(step!=1) {fit=cobs(as.vector(x.hat),as.vector(data),nknots=40,constraint='increase',lambda=lambda,print.warn = FALSE, print.mesg = FALSE);}
        fity=fitted(fit);
        
        x.old=x.new;
        x.new<-NULL;
        
        coefficient=coef_for_spline(fit);
        junk.pred=pred_for_spline(fit);
        prediction=junk.pred$prediction;
        lowerbound=junk.pred$lowerbound;
        
        for(i in 1:(nsamp/nrep))
        {
          xi<-as.vector(t(x.hat[nrep*(i-1)+1:nrep,]));   # x_j+d_l are read
          yi<-as.vector(t(data[nrep*(i-1)+1:nrep,]));
          x.new<-c(x.new,update_x_lam2(xi,yi,fit,XX,coefficient,prediction,lowerbound,balance,nrep,lambda2,x.old,i,fity,data,numsearchpt,windowsize,x.hat,ndilut))
        }
        
        x.new=x.new-median(x.new)
        x.hat<-matrix(rep(x.new,each=ndilut)+rep(balance,nsamp),nrow=nsamp,ncol=ndilut,byrow=T)
        if(step>=step.max-3) Track.x[,(4+step-step.max)]=x.new
        step=step+1
        
      }
      
      fit=cobs(as.vector(x.hat),as.vector(data),nknots=40,constraint='increase',lambda=lambda,print.warn = FALSE, print.mesg = FALSE)
      x.final<-NULL;
      for(jj in 1:(nsamp/nrep)){
        track.xi=Track.x[nrep*(jj-1)+1:nrep,]
        yi=data[nrep*(jj-1)+1:nrep,]
        x.final<-c(x.final,final_x(track.xi,yi,fit,ndilut,nrep,balance))
      }
      x.final<-x.final-median(x.final)
      x.hat.final<-matrix(rep(x.final,each=ndilut)+rep(balance,nsamp),nrow=nsamp,ncol=ndilut,byrow=T)
      fit=cobs(as.vector(x.hat.final),as.vector(data),nknots=40,constraint='increase',lambda=lambda,print.warn = FALSE, print.mesg = FALSE)
      
      fity=fitted(fit)
      est<-NULL
      for(kk in 1:nsamp)
        est<-c(est,getfityrep(x.final[kk]+balance_rec[CVindex],x.hat.final,fity,nrep,data))
    }}
  
  if(CVindex=="NULL") list(fit=fit,x.new=round(x.final,4)) else
    list(fit=fit,x.new=round(x.final,4),est=est)
}
