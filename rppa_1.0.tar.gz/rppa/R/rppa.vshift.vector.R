rppa.vshift.vector <-
function (v, by) 
{
  if (by == 0) return(v)
  
  else if (by >= 0) return(c(NA + 1:by, v[1:(length(v) - by)]))
  
  else return(c(v[(-by + 1):(length(v) - by)]))
}
