getnewxrep <-
function(nrep,fity,xi,datamat,gridsize,windowsize,miny,disminyy,lowxwt,data,x0mat,balance){
  
  datavec=as.vector(datamat)
  allwt=rep(1,length(datavec))
  if (sum((datavec-miny)<=disminyy)>0){
    allwt[(datavec-miny)<=disminyy]=lowxwt
  }
  
  x0vec=as.vector(x0mat[seq(1,dim(data)[1],by=nrep),])
  xicandvec=seq(max(xi-windowsize,sort(x0vec)[6]+1),min(xi+windowsize,-sort(-x0vec)[6]-1),length=gridsize)
  l1dis=NULL
  
  for (j in 1:length(xicandvec)){
    x0dilute=xicandvec[j]+balance
    fitydilute=NULL
    for (k in 1:length(balance)){
      outputk=getfityrep(x0dilute[k],x0mat,fity,nrep,data)
      fitydilute=c(fitydilute,outputk)
    }
    
    fitydilute=rep(fitydilute,each=nrep)
    l1dis=c(l1dis, sum(abs(datavec-fitydilute)*allwt) )
  }
  
  
  output=xicandvec[l1dis==min(l1dis,na.rm=T)]
  len.out=length(output)
  
  if (len.out>1) { loc=as.integer(len.out/2)
                   output=output[loc] }
  minl1=min(l1dis,na.rm=T)
  return(list(output=output,minl1=minl1))
}
