rppa.proteinConc.normalize <-
function(slideA, slideB, normalize.with.median.first = T, 
                                       target.column="Slide", normalize.per.deposition=F, output.all=F)
{   
  #check if target column is free on both slides
  if(output.all && !is.null(slideA[[target.column]]))
  {
    cat("The target column of slideA is not available.")
    return(NA)
  }  
  if(output.all && !is.null(slideB[[target.column]]))
  {
    cat("The target column of slideB is not available.")
    return(NA)
  }
  slideA[[target.column]] <- attr(slideA, "title")
  slideB[[target.column]] <- attr(slideB, "title")
  
  sub.normalize <- function(slideA){
    slideA$upper <- slideA$upper / median(slideA$concentrations, na.rm=T)
    slideA$lower <- slideA$lower / median(slideA$concentrations, na.rm=T)
    slideA$concentrations <- slideA$concentrations / median(slideA$concentrations, na.rm=T)
    return(slideA)
  }
  
  if(normalize.with.median.first)
  {
    if(!normalize.per.deposition){
      slideA <- sub.normalize(slideA)
      slideB <- sub.normalize(slideB)
    }
    else{
      slideA <- ddply(slideA, .(Deposition), sub.normalize)
      slideB <- ddply(slideB, .(Deposition), sub.normalize)
    }
  }
  
  result <- slideA
  result$concentrations <- slideA$concentrations / slideB$concentrations
  #calculate percentage error, build sum and calculate real error on the new value.
  result$upper <- ((( slideA$upper - slideA$concentrations) /slideA$concentrations ) + (( slideB$upper - slideB$concentrations) / slideB$concentrations )) * result$concentrations 
  result$lower <- (( (slideA$concentrations - slideA$lower) / slideA$concentrations ) + ( (slideB$concentrations - slideB$lower) /slideB$concentrations )) * result$concentrations
  
  result$upper <- result$upper + result$concentrations
  result$lower <- result$concentrations - result$lower
  result[[target.column]] <- paste(slideA[[target.column]], "normalized by", slideB[[target.column]])
  if(output.all) result <- rbind(slideA, result, slideB)
    
  return(result)
}
