rppa.set.antibody <-
function(spots, antibody)
{
  attr(spots, "antibody") <- antibody
  
  return(spots)
}
