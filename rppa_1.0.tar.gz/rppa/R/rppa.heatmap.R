rppa.heatmap <-
function(spots){  
  
  require(manipulate)
  
  manipulate(
  rppa.plot.heatmap(spots, log, fill, plotNA, palette, discreteColorA, discreteColorB, NA, NA)
, log = picker("none", "log2", "log10")
, fill = picker("Signal", "FG", "BG","Deposition", "CellLine", "LysisBuffer", "DilutionFactor", "Inducer", "SpotType", "SpotClass", "SampleName", "SampleType", "TargetGene")
, palette = picker("Set1", "Set2", "Set3", "Accent", "Dark2", "Paired", "Pastel1", "Pastel2")
, plotNA = checkbox(TRUE, "Plot NA values")
, discreteColorA = picker("darkblue", "red", "blue", "steelblue", "magenta", "yellow", "white", "green")
, discreteColorB = picker("red", "darkblue", "blue", "steelblue", "magenta", "yellow", "white", "green")
  )
}
