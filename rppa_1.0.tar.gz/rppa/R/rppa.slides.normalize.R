rppa.slides.normalize <-
function(slideList, normalization.slide, specific.dilution=NA, median.normalization=T, combineTitle=T)
{
  require(plyr)
  cat("Warning: It usually makes more sense to normalize protein amount estimates (e.g. serial dilution curve)")
  
  return(llply(slideList, rppa.slide.normalize, normalization.slide, specific.dilution, median.normalization, combineTitle))
}
