rppa.get.antibody <-
function(spots)
{
  attr(spots, "antibody")
}
