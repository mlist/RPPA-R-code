final_x <-
function(track.xi,yi,fit,ndilut,nrep,balance){
  
  Object.f<-NULL;
  
  for (ii in 1:4) {
    xi = matrix(rep(track.xi[,ii],ndilut),nrep,ndilut) + matrix(rep(balance,each=nrep),nrep,ndilut)
    xi = as.vector(xi)
    yi = as.vector(yi)
    Object.f = c(Object.f,sum(abs(track.xi[c(1,1,2),ii]-track.xi[c(2,3,3),ii])) + sum(abs(predict(fit,xi)[,2]-yi)))
  }
  
  pickid=order(Object.f)[1]
  return(track.xi[,pickid])
}
