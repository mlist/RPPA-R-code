coef_for_spline <-
function(fit){
  
  knot=fit$knots;
  
  coefficient<-matrix(0,(length(knot)-1),3)
  colnames(coefficient)=c("x^2","x","1")
  
  for(ii in 1:(length(knot)-1)){
    
    x=(3*knot[ii]+knot[ii+1])/4;
    y=(2*knot[ii]+2*knot[ii+1])/4;
    z=(knot[ii]+3*knot[ii+1])/4;
    
    fx=predict(fit,x)[,2];
    fy=predict(fit,y)[,2];
    fz=predict(fit,z)[,2];
    
    a=-(fy*x - fz*x - fx*y + fz*y + fx*z - fy*z)/((-x + y)*(y - z)*(-x + z))
    b=-(-fy*x^2 + fz*x^2 + fx*y^2 - fz*y^2 - fx*z^2 +
          fy*z^2)/((x - y)*(x - z)*(y - z))
    d=-(-fz*x^2*y + fz*x*y^2 + fy*x^2*z - fx*y^2*z - fy*x*z^2 +
          fx*y*z^2)/((y - z)*(x^2 - x*y - x*z + y*z))
    
    coefficient[ii,]=t(t(c(a,b,d)))
  }
  
  return(coefficient)
}
