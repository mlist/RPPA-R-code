rppa.hshift <-
function(spots)
{
  if(!is.null(attr(spots, "hshifted")))
  {
    cat("This slide has already been vshifted! Do you really want to continue? (yes/no)")
    answer <- readline()
  
    if(answer != "yes") return()
  }
  
  range <- min(spots$Block): max(spots$Block)
  
  for(b in range)
  {
    blockB <- subset(spots, Block == b)
    
    spots[spots$Block==b,] <- unsplit(
      lapply(split(blockB, blockB$Row), function(x)
      {
        by <- unique(x$hshift)
        x <- x[with(x, order(Column)),]
        x$Signal <- rppa.vshift.vector(x$Signal, by)
        x$FG <- rppa.vshift.vector(x$FG, by)
        x$BG <- rppa.vshift.vector(x$BG, by)
        x$Flag <- rppa.vshift.vector(x$Flag, by)
        x$Diameter <- rppa.vshift.vector(x$Diameter, by)
        return(x)
      }), blockB$Row)
  }
  
  attr(spots, "hshifted") <- TRUE
  
  return(spots)
}
