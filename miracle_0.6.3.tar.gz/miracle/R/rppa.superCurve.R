rppa.superCurve <-
function(spots, select.columns.sample=c("CellLine"), 
                            select.columns.A="LysisBuffer", select.columns.B="Inducer", 
                            select.columns.fill="Treatment", return.fit.only=F, model="logistic", 
                            method="nls", ci=T, interactive=T, grouping="nanocan")
{ 
  require(limma)
  require(SuperCurve)
  
  #check for necessary attributes title, antibody, 
  if(is.null(attr(spots, "title"))) return("Please set attribute 'title' first!")
  if(is.null(attr(spots, "antibody"))) return("Please set attribute 'antibody' first!")
  if(is.null(attr(spots, "blocksPerRow")))return("Please set attribute 'blocksPerRow' first!")
  
  #correct inducer format
  #if(length(unique(spots$Inducer)) > 1)
  #  spots$Inducer <- gsub(" [0-9]+[.][0-9] mM", "", spots$Inducer )
  
  #correct dilution factors
  spots$DilutionFactor <- as.double(spots$DilutionFactor)
  
  #create data object for SuperCurve package  
  
  #create sample name from all selected columns  
  Sample <- rppa.superCurve.create.sample.names(spots, select.columns.sample, select.columns.A, select.columns.B, select.columns.fill)
  parsedData <- rppa.superCurve.parse.data(Sample, spots)
  
  #put the information in a RPPA data object
  new.rppa <- rppa.superCurve.create.rppa(parsedData, spots)
  
  #we need the dilution factors as log2 to a reference point, which we will choose to be undiluted 1.0
  steps <- round(log2(spots$DilutionFactor)) + log2(spots$Deposition)
  #steps[is.na(steps)] <- 0
  
  series <- rppa.superCurve.create.series(parsedData, spots)
  
  if(grouping=="nanocan")
    new.design <- RPPADesign(new.rppa, steps=steps, series=new.rppa@data$Sample, controls=list("Control"), center=F)
  else
    new.design <- RPPADesign(new.rppa, grouping=grouping, controls=list("Control"), center=F)
  
  if(interactive){
    image(new.design)
    cat("Here you can see the dilution steps that are assumed to be correct. Press enter to continue.")
    readline()
  }
  
  new.fit <- RPPAFit(new.rppa, new.design, "Mean.Net", ci=ci, method=method, model=model)
  if(return.fit.only) return(new.fit)
  
  if(interactive){
  cat("Here you can see the cloud fit plot that shows you how the model fits the data. Press enter to continue.")
  plot(new.fit)
  readline()
  cat("Here you can see the residual plot. This plot should help you find irregularities and outliers. Press enter to continue.")
  image(new.fit)
  }
  else{
    plot(new.fit)
  }

  new.df <- rppa.superCurve.create.df(new.fit, select.columns.A, select.columns.B, select.columns.fill)
  attr(new.df, "title") <- attr(spots, "title")
  attr(new.df, "antibody") <- attr(spots, "antibody")
  
  return(new.df)
}
