rppa.batch.dunnett.plot <-
function(pvalues, p.cutoff=1)
{
  require(ggplot2)
  require(scales)
  pvalues.subset <- subset(pvalues, pvalues <= p.cutoff)
  pvalues.subset$symbol <- ""
  pvalues.subset[pvalues.subset$pvalues < 0.01, "symbol"] <- "*"
  pvalues.subset[pvalues.subset$pvalues < 0.001, "symbol"] <- "**"
  pvalues.subset[pvalues.subset$pvalues < 0.0001, "symbol"] <- "***"
  limits <- aes(ymax = estimates + stderror, ymin = estimates - stderror)
  q <- qplot(x=Samples, y=estimates, data=pvalues.subset, fill=pvalues, ylab="estimated difference", geom="bar", stat="identity", label=symbol)
  q <- q + geom_errorbar(limits, position="dodge", width=0.25)
  q <- q + theme(axis.text.x = element_text(angle=-45, hjust=0, vjust=1))
  q <- q + scale_fill_gradient2(trans="log", low="red", guide="legend", mid="orange", high="yellow", midpoint=1e-6, breaks=10^(-(seq(-3, 12, by=3))))
  q <- q + facet_grid(slide ~ A + B)
  q <- q + geom_text(aes(y = estimates + stderror), vjust=0.1)
  q <- q + scale_y_continuous(labels = percent)
  print(q)
}
