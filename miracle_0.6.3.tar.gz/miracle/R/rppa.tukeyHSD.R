rppa.tukeyHSD <-
function(slide)
{
  foreach(A = unique(slide$A), .combine=rbind) %do%{
    foreach(B = unique(slide$B), .combine=rbind) %do%{
      slide.subset <- subset(slide, A==A & B==B)
      tukey.df <- as.data.frame(TukeyHSD(aov(concentrations ~ Sample, data=slide.subset), ordered=T)$Sample)
      tukey.df$Samples <- row.names(tukey.df)
      tukey.df$A <- A
      tukey.df$B <- B
      tukey.df$slide <- slide$Slide[1]
      return(tukey.df)
    }
  }
}
