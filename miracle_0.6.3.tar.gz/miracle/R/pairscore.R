pairscore <-
function(data1,data2,distmet="pearson",cmet="average",k=8) {
  antibody2 <- dimnames(data2)[[2]]
  antibody1 <- dimnames(data1)[[2]]
  if (sum(antibody1 != antibody2) != 0) { stop("Names don't match") }
  
  hc1 <- hclust(distanceMatrix(data1, distmet), cmet)
  cutter1 <- cutree(hc1,k=k)		
  names(cutter1) <- antibody1
  sc1 <- matrix(NA,ncol=length(antibody1),nrow=length(antibody1))
  for (i in 1:(length(antibody1)-1)) {
    for (j in (i+1):length(antibody1)) {
      sc1[i,j] <- (cutter1[antibody1[i]]==cutter1[antibody1[j]])+0
    }
  }
  hc2 <- hclust(distanceMatrix(data2, distmet), cmet)
  cutter2 <- cutree(hc2,k=k)
  names(cutter2) <- antibody2
  sc2 <- matrix(NA,ncol=length(antibody2),nrow=length(antibody2))
  for (i in 1:(length(antibody2)-1)) {
    for (j in (i+1):length(antibody2)) {
      sc2[i,j] <- (cutter2[antibody2[i]]==cutter2[antibody2[j]])+0
    }
  }
  sc1 <- sc1[upper.tri(sc1)]
  sc2 <- sc2[upper.tri(sc2)]
  tmp <- abs(sc1-sc2)
  sum(tmp)/length(tmp)
}
