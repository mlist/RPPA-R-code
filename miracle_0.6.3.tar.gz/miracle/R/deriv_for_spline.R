deriv_for_spline <-
function(xx,fit,coefficient){
  
  knot=fit$knots;
  xx=t(t(xx));
  
  xx.tf=t(apply(xx, 1, function(x,knot){x>knot}, knot));
  xx.interval=apply(xx.tf,1,sum);
  
  deri=2*coefficient[xx.interval,1]*xx+coefficient[xx.interval,2]
  
  return(as.vector(deri))
}
