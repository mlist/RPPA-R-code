rppa.superCurve.create.df <-
function(new.fit, select.columns.A, select.columns.B, select.columns.fill, log2=F)
{
  if(log2) new.fit <- data.frame(concentrations=new.fit@concentrations, lower=new.fit@lower, upper=new.fit@upper)
  else new.fit <- data.frame(concentrations=2^new.fit@concentrations, lower=2^new.fit@lower, upper=2^new.fit@upper)
  
  #new.fit$concentrations <- new.fit$concentrations
  
  new.cols <- strsplit2(row.names(new.fit), " # ")
  new.cols <- as.data.frame(new.cols)
  
  col.temp <- c("Sample")
  if(!is.na(select.columns.A)) col.temp <- c(col.temp, "A")
  if(!is.na(select.columns.B)) col.temp <- c(col.temp, "B")
  if(!is.na(select.columns.fill)) col.temp <- c(col.temp, "Fill")
  
  colnames(new.cols) <- col.temp
  
  #fix NAs
  new.cols[new.cols=="NA"] <- NA
  new.cols <- apply(new.cols, 2, factor)
  
  new.df <- cbind(new.fit, new.cols)
  
  return(new.df)
}
