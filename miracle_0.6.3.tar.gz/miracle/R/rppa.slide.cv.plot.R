rppa.slide.cv.plot <-
function(spots, plotSampleNumber=T){
  require(ggplot2)
  require(scales)
  require(gridExtra)
  
  #plot CVs
  q <- qplot(as.factor(Deposition), Signal, data=subset(spots, !is.na(DilutionFactor) & !is.na(Deposition)),  
        xlab="Depositions",
        ylab="CV of Signal",
        geom="bar", 
        fill=SampleName,
        stat="summary", 
        fun.y="rppa.calculate.cv") 
  q <- q + facet_grid(SampleName~DilutionFactor) + opts(legend.title=theme_blank())
  q <- q + scale_y_continuous(labels=percent)
  
  #plot sample size
  smplsize <- qplot(as.factor(Deposition), Signal, data=subset(spots, !is.na(DilutionFactor) & !is.na(Deposition)), 
             main="Sample Size", 
             xlab="Depositions",
             ylab="Samples",
             geom="bar",
             position="dodge",
             fill=SampleName,
             stat="summary", 
             fun.y="length") 
  smplsize <- smplsize + facet_grid(~DilutionFactor) + opts(legend.position="none")
  
  sidebysideplot <- grid.arrange(q, smplsize, heights=c(3/4, 1/4))
  
  print(sidebysideplot)
}
