rppa.set.blocksPerRow <-
function(spots, blocksPerRow)
{
  attr(spots, "blocksPerRow") <- blocksPerRow
  
  return(spots)
}
