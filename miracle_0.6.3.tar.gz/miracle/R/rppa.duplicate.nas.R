rppa.duplicate.nas <-
function(data.protein.conc.copy)
{
  foreach(property=c("A","B")) %do%{
    data.protein.conc.copy <- foreach(i=1:nrow(data.protein.conc.copy), .combine=rbind) %do%  {
      if(is.na(data.protein.conc.copy[i,property])){
        foreach(A=levels(data.protein.conc.copy[[property]]), .combine=rbind) %do% {
          currentRow <- data.protein.conc.copy[i,]
          currentRow[[property]] <- A
          return(currentRow)
        }
      }
      else return(data.protein.conc.copy[i,])
    }
  }
  return(data.protein.conc.copy)
}
