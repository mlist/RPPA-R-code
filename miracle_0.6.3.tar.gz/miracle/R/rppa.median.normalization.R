rppa.median.normalization <-
function(spots){
  if(!is.null(attr(spots, "median.normalized"))) cat("Warning: This slide has been median normalized before!")
  
  spots$Signal = spots$Signal / median(spots$Signal, na.rm=T)
  spots$FG = spots$FG / median(spots$FG, na.rm=T)
  spots$BG = spots$BG / median(spots$BG, na.rm=T)
  attr(spots, "median.normalized") <- TRUE
  
  return(spots)
}
