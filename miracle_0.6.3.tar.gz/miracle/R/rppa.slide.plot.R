rppa.slide.plot <-
function(spots, select.columns.sample="CellLine", 
                            select.columns.A="LysisBuffer",
                            select.columns.B="Inducer", select.columns.fill="Deposition")
{
  require(ggplot2)
  spots <- subset(spots, !is.na(DilutionFactor))
  
  limits <- aes(ymax = mean + sd, ymin= mean - sd)
  
  spots$Deposition <- as.factor(spots$Deposition)
  q <- qplot(aes_string(select.columns.sample), Signal, data=spots, geom="bar", fill=aes_string(select.columns.fill), position="dodge", stat="summary", fun.y="mean") + facet_grid(aes_string(select.columns.A)~aes_string(select.columns.B))
  print(q)
}
