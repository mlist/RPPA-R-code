ea <-
function(a) {2^(a)/(1+2^(a))}
