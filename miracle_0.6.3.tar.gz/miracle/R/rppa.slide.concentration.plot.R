rppa.slide.concentration.plot <-
function(spots, title="", select.columns.A="CellLine", select.columns.B="Inducer", x.log2=T, y.log2=T, only.samples=T){
  require(ggplot2)
  spots <- subset(spots, !is.na(Signal))
  if(only.samples) spots <- subset(spots, SpotClass=="Sample")
  spots$Concentration <- spots$DilutionFactor * spots$Deposition
  spots$Deposition <- as.factor(spots$Deposition)
  spots$DilutionFactor <- as.factor(spots$DilutionFactor)
  spots$A <- spots[,select.columns.A]
  spots$B <- spots[,select.columns.B]
  
  q <- qplot(Concentration, Signal, data=spots, main=title, color=Deposition, shape=DilutionFactor) 
  q <- q + geom_point(position = position_jitter(width=0.1))
  q <- q + stat_smooth(aes(group=1), method="loess")
  
  if(!is.null(spots$A) && !is.null(spots$B))
  {
    q <- q + facet_grid(A~B)
  }
  else if(!is.null(spots$A))
  {
    q <- q + facet_grid(~A)
  }
  else if(!is.null(spots$B))
  {
    q <- q + facet_grid(~B)
  }
  
  if(x.log2)
  {
    q <- q + scale_x_continuous(trans="log2", name="log2(Concentration)")
  }
  if(y.log2)
  {
    q <- q + scale_y_continuous(trans="log2", name="log2(Signal)")
  }
  print(q)
}
