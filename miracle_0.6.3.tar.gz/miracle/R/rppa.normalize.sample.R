rppa.normalize.sample <-
function(spots, sampleReference, signalColumn="Signal", normalize.each.cellLine=T){
  
  toRefSample <- function(spots){
    meanOfRefSample <- mean(subset(spots, SampleName == sampleReference)[[signalColumn]], na.rm=T)
    spots[[signalColumn]] <- spots[[signalColumn]] / meanOfRefSample
    return(spots)
  }
  
  if(normalize.each.cellLine){  
    spots <- ddply(spots, .(CellLine), toRefSample)
  }
  else 
  {
    spots <- toRefSample(spots)
  }
  
  return(spots)
}
